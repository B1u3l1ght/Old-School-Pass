#!/bin/bash
echo " "
echo "      ➢  Zero Trust Pass, Old School pwd "
echo "        "
sleep 0.1s
echo "      ➢  Search Space Depth 94, pass chassis 24|18|18| 3| "
echo "---------------------------------------------------------------"
{
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
sleep 0.3s
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
tr -Cd '!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' < /dev/random | head -c1
sleep 0.3s
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
sleep 0.3s
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
tr -Cd 'abcdefghijklmnopqrstuvwxyz' < /dev/random | head -c1
sleep 0.3s
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
sleep 0.3s
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
tr -Cd 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' < /dev/random | head -c1
sleep 0.3s
tr -Cd '0123456789' < /dev/random | head -c1
tr -Cd '0123456789' < /dev/random | head -c1
tr -Cd '0123456789' < /dev/random | head -c1
} | fold -w 1 | shuf | shuf | shuf | shuf | shuf | shuf | shuf | tr -d '\n' | tr -d '  ' > fin
cat fin
echo "
---------------------------------------------------------------"
echo "  "
echo "      ➢  String gen. success"
#echo "           "
echo "           +------------+ "
echo "           | Char stats |   "
echo "-----------+            +---------------------------------------------------------------------"
cat ord
{
awk -F '!' '{s+=(NF-1)} END {print s}' fin
awk -F '"' '{s+=(NF-1)} END {print s}' fin
awk -F '#' '{s+=(NF-1)} END {print s}' fin
awk -F '$' '{s+=(NF-1)} END {print s}' fin
awk -F '%' '{s+=(NF-1)} END {print s}' fin
awk -F '&' '{s+=(NF-1)} END {print s}' fin
awk -F ''\''' '{s+=(NF-1)} END {print s}' fin
awk -F '(' '{s+=(NF-1)} END {print s}' fin
awk -F ')' '{s+=(NF-1)} END {print s}' fin
awk -F '*' '{s+=(NF-1)} END {print s}' fin
awk -F '+' '{s+=(NF-1)} END {print s}' fin
awk -F ',' '{s+=(NF-1)} END {print s}' fin
awk -F '-' '{s+=(NF-1)} END {print s}' fin
awk -F '.' '{s+=(NF-1)} END {print s}' fin
awk -F '/' '{s+=(NF-1)} END {print s}' fin
awk -F ':' '{s+=(NF-1)} END {print s}' fin
awk -F ';' '{s+=(NF-1)} END {print s}' fin
awk -F '<' '{s+=(NF-1)} END {print s}' fin
awk -F '=' '{s+=(NF-1)} END {print s}' fin
awk -F '>' '{s+=(NF-1)} END {print s}' fin
awk -F '?' '{s+=(NF-1)} END {print s}' fin
awk -F '@' '{s+=(NF-1)} END {print s}' fin
awk -F '[' '{s+=(NF-1)} END {print s}' fin
awk -F '\' '{s+=(NF-1)} END {print s}' fin
awk -F ']' '{s+=(NF-1)} END {print s}' fin
awk -F '^' '{s+=(NF-1)} END {print s}' fin
awk -F '_' '{s+=(NF-1)} END {print s}' fin
awk -F '`' '{s+=(NF-1)} END {print s}' fin
awk -F '{' '{s+=(NF-1)} END {print s}' fin
awk -F '|' '{s+=(NF-1)} END {print s}' fin
awk -F '}' '{s+=(NF-1)} END {print s}' fin
awk -F '~' '{s+=(NF-1)} END {print s}' fin
awk -F 'a' '{s+=(NF-1)} END {print s}' fin
awk -F 'b' '{s+=(NF-1)} END {print s}' fin
awk -F 'c' '{s+=(NF-1)} END {print s}' fin
awk -F 'd' '{s+=(NF-1)} END {print s}' fin
awk -F 'e' '{s+=(NF-1)} END {print s}' fin
awk -F 'f' '{s+=(NF-1)} END {print s}' fin
awk -F 'g' '{s+=(NF-1)} END {print s}' fin
awk -F 'h' '{s+=(NF-1)} END {print s}' fin
awk -F 'i' '{s+=(NF-1)} END {print s}' fin
awk -F 'j' '{s+=(NF-1)} END {print s}' fin
awk -F 'k' '{s+=(NF-1)} END {print s}' fin
awk -F 'l' '{s+=(NF-1)} END {print s}' fin
awk -F 'm' '{s+=(NF-1)} END {print s}' fin
awk -F 'n' '{s+=(NF-1)} END {print s}' fin
awk -F 'o' '{s+=(NF-1)} END {print s}' fin
awk -F 'p' '{s+=(NF-1)} END {print s}' fin
awk -F 'q' '{s+=(NF-1)} END {print s}' fin
awk -F 'r' '{s+=(NF-1)} END {print s}' fin
awk -F 's' '{s+=(NF-1)} END {print s}' fin
awk -F 't' '{s+=(NF-1)} END {print s}' fin
awk -F 'u' '{s+=(NF-1)} END {print s}' fin
awk -F 'v' '{s+=(NF-1)} END {print s}' fin
awk -F 'w' '{s+=(NF-1)} END {print s}' fin
awk -F 'x' '{s+=(NF-1)} END {print s}' fin
awk -F 'y' '{s+=(NF-1)} END {print s}' fin
awk -F 'z' '{s+=(NF-1)} END {print s}' fin
awk -F 'A' '{s+=(NF-1)} END {print s}' fin
awk -F 'B' '{s+=(NF-1)} END {print s}' fin
awk -F 'C' '{s+=(NF-1)} END {print s}' fin
awk -F 'D' '{s+=(NF-1)} END {print s}' fin
awk -F 'E' '{s+=(NF-1)} END {print s}' fin
awk -F 'F' '{s+=(NF-1)} END {print s}' fin
awk -F 'G' '{s+=(NF-1)} END {print s}' fin
awk -F 'H' '{s+=(NF-1)} END {print s}' fin
awk -F 'I' '{s+=(NF-1)} END {print s}' fin
awk -F 'J' '{s+=(NF-1)} END {print s}' fin
awk -F 'K' '{s+=(NF-1)} END {print s}' fin
awk -F 'L' '{s+=(NF-1)} END {print s}' fin
awk -F 'M' '{s+=(NF-1)} END {print s}' fin
awk -F 'N' '{s+=(NF-1)} END {print s}' fin
awk -F 'O' '{s+=(NF-1)} END {print s}' fin
awk -F 'P' '{s+=(NF-1)} END {print s}' fin
awk -F 'Q' '{s+=(NF-1)} END {print s}' fin
awk -F 'R' '{s+=(NF-1)} END {print s}' fin
awk -F 'S' '{s+=(NF-1)} END {print s}' fin
awk -F 'T' '{s+=(NF-1)} END {print s}' fin
awk -F 'U' '{s+=(NF-1)} END {print s}' fin
awk -F 'V' '{s+=(NF-1)} END {print s}' fin
awk -F 'W' '{s+=(NF-1)} END {print s}' fin
awk -F 'X' '{s+=(NF-1)} END {print s}' fin
awk -F 'Y' '{s+=(NF-1)} END {print s}' fin
awk -F 'Z' '{s+=(NF-1)} END {print s}' fin
awk -F '0' '{s+=(NF-1)} END {print s}' fin
awk -F '1' '{s+=(NF-1)} END {print s}' fin
awk -F '2' '{s+=(NF-1)} END {print s}' fin
awk -F '3' '{s+=(NF-1)} END {print s}' fin
awk -F '4' '{s+=(NF-1)} END {print s}' fin
awk -F '5' '{s+=(NF-1)} END {print s}' fin
awk -F '6' '{s+=(NF-1)} END {print s}' fin
awk -F '7' '{s+=(NF-1)} END {print s}' fin
awk -F '8' '{s+=(NF-1)} END {print s}' fin
awk -F '9' '{s+=(NF-1)} END {print s}' fin
}  | fold -w 1 | tr -d '\n' | tr -d '  ' > allc
cat allc
echo "    "
echo "----------------------------------------------------------------------------------------------
"
echo " Z's amount"
awk -F '0' '{s+=(NF-1)} END {print s}' allc
echo "   "
cat ord2
rm fin allc
echo "  
"
echo "      ➢  Temp files cleared"
echo "      "
echo "      ➢  Done"
echo "                                                          
      ➢  [Artix community, ⚁ ０⚁ ⚁ ]"
echo " "
sleep 7s
tail --lines=+7 osp.sh | sh
exec bash