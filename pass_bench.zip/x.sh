echo "     "
cat fin
echo " 
   "
awk -F '!' '{s+=(NF-1)} END {print s}' fin > count1
awk -F '"' '{s+=(NF-1)} END {print s}' fin > count2
awk -F '#' '{s+=(NF-1)} END {print s}' fin > count3
awk -F '$' '{s+=(NF-1)} END {print s}' fin > count4
awk -F '%' '{s+=(NF-1)} END {print s}' fin > count5
awk -F '&' '{s+=(NF-1)} END {print s}' fin > count6
awk -F ''\''' '{s+=(NF-1)} END {print s}' fin > count7
awk -F '(' '{s+=(NF-1)} END {print s}' fin > count8
awk -F ')' '{s+=(NF-1)} END {print s}' fin > count9
awk -F '*' '{s+=(NF-1)} END {print s}' fin > count10
awk -F '+' '{s+=(NF-1)} END {print s}' fin > count11
awk -F ',' '{s+=(NF-1)} END {print s}' fin > count12
awk -F '-' '{s+=(NF-1)} END {print s}' fin > count13
awk -F '.' '{s+=(NF-1)} END {print s}' fin > count14
awk -F '/' '{s+=(NF-1)} END {print s}' fin > count15
awk -F ':' '{s+=(NF-1)} END {print s}' fin > count16
awk -F ';' '{s+=(NF-1)} END {print s}' fin > count17
awk -F '<' '{s+=(NF-1)} END {print s}' fin > count18
awk -F '=' '{s+=(NF-1)} END {print s}' fin > count19
awk -F '>' '{s+=(NF-1)} END {print s}' fin > count20
awk -F '?' '{s+=(NF-1)} END {print s}' fin > count21
awk -F '@' '{s+=(NF-1)} END {print s}' fin > count22
awk -F '[' '{s+=(NF-1)} END {print s}' fin > count23
awk -F '\' '{s+=(NF-1)} END {print s}' fin > count24
awk -F ']' '{s+=(NF-1)} END {print s}' fin > count25
awk -F '^' '{s+=(NF-1)} END {print s}' fin > count26
awk -F '_' '{s+=(NF-1)} END {print s}' fin > count27
awk -F '`' '{s+=(NF-1)} END {print s}' fin > count28
awk -F '{' '{s+=(NF-1)} END {print s}' fin > count29
awk -F '|' '{s+=(NF-1)} END {print s}' fin > count30
awk -F '}' '{s+=(NF-1)} END {print s}' fin > count31
awk -F '~' '{s+=(NF-1)} END {print s}' fin > count32
awk -F 'a' '{s+=(NF-1)} END {print s}' fin > count33
awk -F 'b' '{s+=(NF-1)} END {print s}' fin > count34
awk -F 'c' '{s+=(NF-1)} END {print s}' fin > count35
awk -F 'd' '{s+=(NF-1)} END {print s}' fin > count36
awk -F 'e' '{s+=(NF-1)} END {print s}' fin > count37
awk -F 'f' '{s+=(NF-1)} END {print s}' fin > count38
awk -F 'g' '{s+=(NF-1)} END {print s}' fin > count39
awk -F 'h' '{s+=(NF-1)} END {print s}' fin > count40
awk -F 'i' '{s+=(NF-1)} END {print s}' fin > count41
awk -F 'j' '{s+=(NF-1)} END {print s}' fin > count42
awk -F 'k' '{s+=(NF-1)} END {print s}' fin > count43
awk -F 'l' '{s+=(NF-1)} END {print s}' fin > count44
awk -F 'm' '{s+=(NF-1)} END {print s}' fin > count45
awk -F 'n' '{s+=(NF-1)} END {print s}' fin > count46
awk -F 'o' '{s+=(NF-1)} END {print s}' fin > count47
awk -F 'p' '{s+=(NF-1)} END {print s}' fin > count48
awk -F 'q' '{s+=(NF-1)} END {print s}' fin > count49
awk -F 'r' '{s+=(NF-1)} END {print s}' fin > count50
awk -F 's' '{s+=(NF-1)} END {print s}' fin > count51
awk -F 't' '{s+=(NF-1)} END {print s}' fin > count52
awk -F 'u' '{s+=(NF-1)} END {print s}' fin > count53
awk -F 'v' '{s+=(NF-1)} END {print s}' fin > count54
awk -F 'w' '{s+=(NF-1)} END {print s}' fin > count55
awk -F 'x' '{s+=(NF-1)} END {print s}' fin > count56
awk -F 'y' '{s+=(NF-1)} END {print s}' fin > count57
awk -F 'z' '{s+=(NF-1)} END {print s}' fin > count58
awk -F 'A' '{s+=(NF-1)} END {print s}' fin > count59
awk -F 'B' '{s+=(NF-1)} END {print s}' fin > count60
awk -F 'C' '{s+=(NF-1)} END {print s}' fin > count61
awk -F 'D' '{s+=(NF-1)} END {print s}' fin > count62
awk -F 'E' '{s+=(NF-1)} END {print s}' fin > count63
awk -F 'F' '{s+=(NF-1)} END {print s}' fin > count64
awk -F 'G' '{s+=(NF-1)} END {print s}' fin > count65
awk -F 'H' '{s+=(NF-1)} END {print s}' fin > count66
awk -F 'I' '{s+=(NF-1)} END {print s}' fin > count67
awk -F 'J' '{s+=(NF-1)} END {print s}' fin > count68
awk -F 'K' '{s+=(NF-1)} END {print s}' fin > count69
awk -F 'L' '{s+=(NF-1)} END {print s}' fin > count70
awk -F 'M' '{s+=(NF-1)} END {print s}' fin > count71
awk -F 'N' '{s+=(NF-1)} END {print s}' fin > count72
awk -F 'O' '{s+=(NF-1)} END {print s}' fin > count73
awk -F 'P' '{s+=(NF-1)} END {print s}' fin > count74
awk -F 'Q' '{s+=(NF-1)} END {print s}' fin > count75
awk -F 'R' '{s+=(NF-1)} END {print s}' fin > count76
awk -F 'S' '{s+=(NF-1)} END {print s}' fin > count77
awk -F 'T' '{s+=(NF-1)} END {print s}' fin > count78
awk -F 'U' '{s+=(NF-1)} END {print s}' fin > count79
awk -F 'V' '{s+=(NF-1)} END {print s}' fin > count80
awk -F 'W' '{s+=(NF-1)} END {print s}' fin > count81
awk -F 'X' '{s+=(NF-1)} END {print s}' fin > count82
awk -F 'Y' '{s+=(NF-1)} END {print s}' fin > count83
awk -F 'Z' '{s+=(NF-1)} END {print s}' fin > count84
awk -F '0' '{s+=(NF-1)} END {print s}' fin > count85
awk -F '1' '{s+=(NF-1)} END {print s}' fin > count86
awk -F '2' '{s+=(NF-1)} END {print s}' fin > count87
awk -F '3' '{s+=(NF-1)} END {print s}' fin > count88
awk -F '4' '{s+=(NF-1)} END {print s}' fin > count89
awk -F '5' '{s+=(NF-1)} END {print s}' fin > count90
awk -F '6' '{s+=(NF-1)} END {print s}' fin > count91
awk -F '7' '{s+=(NF-1)} END {print s}' fin > count92
awk -F '8' '{s+=(NF-1)} END {print s}' fin > count93
awk -F '9' '{s+=(NF-1)} END {print s}' fin > count94
cat count1 count2 count3 count4 count5 count6 count7 count8 count9 count10 count11 count12 count13 count14 count15 count16 count17 count18 count19 count20 count21 count22 count23 count24 count25 count26 count27 count28 count29 count30 count31 count32 count33 count34 count35 count36 count37 count38 count39 count40 count41 count42 count43 count44 count45 count46 count47 count48 count49 count50 count51 count52 count53 count54 count55 count56 count57 count58 count59 count60 count61 count62 count63 count64 count65 count66 count67 count68 count69 count70 count71 count72 count73 count74 count75 count76 count77 count78 count79 count80 count81 count82 count83 count84 count85 count86 count87 count88 count89 count90 count91 count92 count93 count94 > allc
#cat fin | tr -d '\n' | tr -d '  ' > string
#echo "---------------------------------------------------------------"
#cat string
#echo "
#---------------------------------------------------------------"
#rm string sf sf1 t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24 t25 t26 t27 t28 t29 t30 t31 t32 t33 t34 t35 t36 t37 t38 t39 t40 t41 t42 t43 t44 t45 t46 t47 t48 t49 t50 t51 t52 t53 t54 t55 t56 t57 t58 t59 t60 t61 t62 t63
#echo "      ➢  String generated successfully"
#echo "         -----------------------------"
#echo "      ➢  Temp files cleared"
#echo "         ------------------"
#echo "      ➢  Char stats"
#echo "         ----------"
#echo "     "
cat allc | tr -d '\n' > tc4
cat ord
echo "   "
cat tc4
echo " 
  "
awk -F '0' '{s+=(NF-1)} END {print s}' tc4 > fin_ct
echo "Z's amount"
cat fin_ct
cat ord2
rm fin_ct tc4 allc count1 count2 count3 count4 count5 count6 count7 count8 count9 count10 count11 count12 count13 count14 count15 count16 count17 count18 count19 count20 count21 count22 count23 count24 count25 count26 count27 count28 count29 count30 count31 count32 count33 count34 count35 count36 count37 count38 count39 count40 count41 count42 count43 count44 count45 count46 count47 count48 count49 count50 count51 count52 count53 count54 count55 count56 count57 count58 count59 count60 count61 count62 count63 count64 count65 count66 count67 count68 count69 count70 count71 count72 count73 count74 count75 count76 count77 count78 count79 count80 count81 count82 count83 count84 count85 count86 count87 count88 count89 count90 count91 count92 count93 count94
echo "  
"
echo "      ➢  Done"
echo "                                                          

                                                           ⚀ ⚁ ⚂ [Artix community, 2022] ⚃ ⚄ ⚅"
echo " "
exec bash